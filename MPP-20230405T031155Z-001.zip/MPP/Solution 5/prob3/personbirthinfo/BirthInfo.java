package lesson5.labsolns.prob4.personbirthinfo;

import java.time.LocalDate;

public class BirthInfo {
	private LocalDate dateOfBirth;	
	BirthInfo(LocalDate dob) {
		dateOfBirth = dob;
	}
}
