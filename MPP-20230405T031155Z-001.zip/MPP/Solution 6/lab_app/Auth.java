package lesson6.labsolns.lab_app;

import java.io.Serializable;

public enum Auth implements Serializable {
	MEMBER, SELLER, BOTH;
}
