package lesson4.labsolns.prob4C;

public class Main {

	public static void main(String[] args) {
		//Employee e = new Commissioned(...);
		//  ... populate it
		//Paycheck p = e.calcCompensation(10, 2021);
		//double netPay = p.getNetPay();

	}

}
