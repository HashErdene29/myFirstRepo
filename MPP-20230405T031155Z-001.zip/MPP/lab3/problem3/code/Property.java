package lesson3.labsolns.prob4;

abstract public class Property {
	abstract double computeRent();
}
