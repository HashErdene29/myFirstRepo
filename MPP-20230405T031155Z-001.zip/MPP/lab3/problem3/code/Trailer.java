package lesson3.labsolns.prob4;

public class Trailer extends Property {

	public double computeRent(){
		return 500;
	}
}
